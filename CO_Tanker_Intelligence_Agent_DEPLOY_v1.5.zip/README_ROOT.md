# CO Tanker Intelligence · v1.5

This package is a **deployable project** for a best-effort scheduled public-source monitor plus Chrome and Android PWA frontends. It will **not** fetch while all devices are off until you upload the deployment archive to an actual GitHub repository and activate its GitHub Actions/Pages workflow.

For nontechnical setup, read **DEPLOY_START_HERE_PL.md**.

## Folders
- `.github/workflows/collect.yml`: scheduled source-collection + explicit Pages deploy
- `agent/collector.py`: public HTML/RSS link collector
- `agent/sources.json`: curated list of public maritime sources
- `agent/test_collector.py`: tests
- `docs/`: hosted mobile PWA and public JSON feed (initially NOT_DEPLOYED)

## Output constraints
- No private ship data is sent to collector. Public index contains links and source-linked research prompts only.
- Legal applicability and effective dates are not determined from scraped listing titles.
- Blocking, login-only and paywalled sources are reported as unavailable.

See CHANGELOG_v1.5.md, KNOWN_LIMITATIONS_v1.5.md and QA_REPORT_v1.5.md.
