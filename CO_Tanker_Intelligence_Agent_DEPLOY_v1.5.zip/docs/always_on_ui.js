// Always-On Watch v1.5: transparent client for a deployed, independently scheduled public feed.
// This module NEVER claims a server exists until a real feed is received.
const K='coIntelligenceAlwaysOnV1';
const $=id=>document.getElementById(id);
const el=(tag,cls,txt)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=String(txt);return e;};
const safeURL=url=>{try{const u=new URL(url);return u.protocol==='https:'?u.href:null;}catch{return null;}};
const isChrome=location.protocol==='chrome-extension:';
const DEFAULT_URL=isChrome?'':'./data/intelligence.json';
let watch={url:DEFAULT_URL,seen:[],cached:null,lastRead:'',lastError:''};
try{const data=JSON.parse(localStorage.getItem(K)||'null');if(data&&typeof data==='object')watch={...watch,...data};}catch{}
const save=()=>{try{localStorage.setItem(K,JSON.stringify({...watch,seen:(watch.seen||[]).slice(-1000),cached:watch.cached}));}catch{setStatus('Local storage unavailable: your saved Watch state may not persist.',true);}};
let pending=false;
function setStatus(s,bad=false){const x=$('watchStatus');if(x){x.textContent=s;x.style.color=bad?'#ffbb9e':'#9dded2';}}
function officialLink(url,text){const a=el('a','reference-short',text);const clean=safeURL(url);if(clean){a.href=clean;a.target='_blank';a.rel='noopener noreferrer';}else a.textContent=text+' (invalid URL)';return a;}
function validateFeed(data){
 if(!data||data.schema_version!==1||!Array.isArray(data.entries)||!Array.isArray(data.lessons)||!Array.isArray(data.sources))throw Error('Unrecognised feed format (expected schema_version 1)');
 if(data.entries.length>2000||data.lessons.length>2000)throw Error('Feed is too large');
 return data;
}
function watchedRecent(item){return !(watch.seen||[]).includes(item.id);}
function renderWatch(){
 const status=$('watchStatus');if(!status)return;
 $('watchFeedUrl').value=watch.url||'';
 const root=$('watchEntries'),lessons=$('watchLessons'),source=$('watchSources');root.replaceChildren();lessons.replaceChildren();source.replaceChildren();
 const d=watch.cached;
 if(!d){setStatus('NOT CONNECTED — no scheduled-server data received. Previous local news monitoring remains available.');return;}
 const gen=d.generated_at||'',last=gen?new Date(gen):null,hours=last?(Date.now()-last.getTime())/36e5:NaN;
 const age=Number.isFinite(hours)?`${Math.round(hours)}h ago`:'unknown age';
 const updated=d.collector_status==='NOT_DEPLOYED'?'COLLECTOR NOT DEPLOYED':d.collector_status==='ALL_SOURCES_FAILED'?'ALL SOURCES FAILED — check workflow logs':Number.isFinite(hours)&&hours>12?'STALE FEED — last published '+age:'Last published '+age;
 setStatus(`${updated} · ${d.entries.length} article links · ${d.lessons.length} guided study prompts · ${d.sources.filter(s=>s.ok).length}/${d.sources.length} sources successful`,d.collector_status!=='RUN_COMPLETED'||(Number.isFinite(hours)&&hours>12));
 const stale=el('p','micro','Publication links were collected from listing pages. Content, legal status and effective dates are NOT verified. No automatic compliance approval.');root.append(stale);
 let count=0;
 for(const item of d.entries){if(count++>=80)break;const c=el('article','watch-card');const r=el('div','watch-card-head');r.append(el('span','watch-chip',item.source_name||item.source_id),el('span','watch-chip',item.topic||'General'),el('span','watch-chip',item.discovered_at?.slice(0,10)||''));const h=el('h3','',item.title||'Untitled');const link=officialLink(item.url,'View original publication ↗');const note=el('p','micro',item.status_label||'Primary source page linked; legal applicability unverified');const mark=el('button','button-outline small',watchedRecent(item)?'Mark reviewed':'Reviewed ✓');mark.addEventListener('click',()=>{const set=new Set(watch.seen||[]);set.has(item.id)?set.delete(item.id):set.add(item.id);watch.seen=[...set];save();renderWatch();});c.append(r,h,note,link,mark);root.append(c);}
 if(!count)root.append(el('p','subtle','No source links have been collected yet. Review source health below.'));
 let countLessons=0;
 for(const l of d.lessons){if(countLessons++>=24)break;const c=el('article','watch-card');c.append(el('span','watch-chip',l.status||'GUIDED RESEARCH / DRAFT'),el('h3','',l.title||'Study prompt'),el('p','subtle',l.learning_objective||''));const p=el('div','watch-points');for(const q of (l.questions||[]).slice(0,4))p.append(el('p','', '• '+q));c.append(p,el('p','micro','Training exercise, not an official legal interpretation or operational procedure.'),officialLink(l.source_url,'Read primary source ↗'));lessons.append(c);}
 if(!countLessons)lessons.append(el('p','subtle','No new study prompts yet. Existing CO Academy lessons remain available offline.'));
 for(const s of d.sources){const item=el('div','watch-source');item.append(el('strong','',s.name||s.id),el('span',s.ok?'status-ok':'status-fail',s.ok?'OK · '+(s.last_success||'unknown date'):'FAILED · '+String(s.error||'Unavailable').slice(0,110)));source.append(item);}
}
async function refreshWatch(){
 if(pending)return;pending=true;
 try{
   const url=(watch.url||'').trim()||DEFAULT_URL;
   if(!url)throw Error('Enter your published HTTPS feed URL first.');
   if(isChrome&&!safeURL(url))throw Error('Chrome requires a published HTTPS JSON feed.');
   if(!isChrome&&!safeURL(url)&&!url.startsWith('./'))throw Error('Enter a same-site relative path or HTTPS URL.');
   setStatus('Loading published feed…');
   const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),13000);
   let response;
   try{response=await fetch(url,{cache:'no-store',signal:controller.signal,credentials:'omit'});}finally{clearTimeout(timeout);}
   if(!response.ok)throw Error('Feed HTTP '+response.status+'. Has the scheduled collector been deployed?');
   if(Number(response.headers.get('content-length')||0)>1500000)throw Error('Feed exceeds allowed size');
   const raw=await response.text();if(raw.length>1500000)throw Error('Feed exceeds allowed size');
   const data=validateFeed(JSON.parse(raw));
   watch.cached=data;watch.lastRead=new Date().toISOString();watch.lastError='';save();renderWatch();
 }catch(e){watch.lastError=String(e.message||e);save();renderWatch();setStatus('Feed not refreshed: '+watch.lastError+' · Showing last stored snapshot if available.',true);}
 finally{pending=false;}
}
export function exportWatchBackup(){return {url:watch.url,seen:watch.seen,lastRead:watch.lastRead};}
export function importWatchBackup(data){if(!data||typeof data!=='object')return;watch.url=typeof data.url==='string'&&data.url.length<500?data.url:DEFAULT_URL;watch.seen=Array.isArray(data.seen)?data.seen.filter(x=>typeof x==='string').slice(-1000):[];watch.cached=null;save();renderWatch();}
export function wireWatch(){
 const saveBtn=$('watchSaveUrl');if(!saveBtn)return;
 saveBtn.addEventListener('click',async()=>{
  const u=$('watchFeedUrl').value.trim();if(!u){watch.url=DEFAULT_URL;save();renderWatch();return;}
  let parsed;try{parsed=new URL(u,location.href);if(parsed.protocol!=='https:')throw Error('Only HTTPS feeds are supported');}catch{setStatus('Enter a valid HTTPS feed URL',true);return;}
  if(isChrome){try{const ok=await chrome.permissions.request({origins:[parsed.origin+'/*']});if(!ok){setStatus('Chrome permission was not granted.',true);return;}}catch(e){setStatus('Permission error: '+e.message,true);return;}}
  watch.url=parsed.href;save();await refreshWatch();
 });
 $('watchRefresh').addEventListener('click',refreshWatch);
 $('watchMarkAll').addEventListener('click',()=>{if(!watch.cached)return;watch.seen=[...new Set([...(watch.seen||[]),...watch.cached.entries.map(x=>x.id)])].slice(-1000);save();renderWatch();});
 renderWatch();
}
export function onWatchPage(){renderWatch();if(!watch.lastRead||Date.now()-Date.parse(watch.lastRead)>20*60*1000)refreshWatch();}
