# CO Tanker Intelligence 1.5 — jak uruchomić autonomicznego agenta

Wersja v1.5 to **gotowy do wdrożenia projekt**, a nie istniejący, działający 24/7 serwer. Dopiero po wykonaniu opisanych czynności agent będzie automatycznie próbował sprawdzać źródła przy wyłączonym telefonie/komputerze.

## Najłatwiej: GitHub Actions + GitHub Pages (bez VPS i bez klucza AI)

1. Załóż repozytorium GitHub, np. `co-tanker-intelligence`. **Uwaga: publiczne GitHub Pages opublikuje publicznie wiadomości i kod PWA; nie umieszczaj tam danych statku, QMS, nazw załogi ani haseł.**
2. Rozpakuj **CO_Tanker_Intelligence_Agent_DEPLOY_v1.5.zip**. Wgraj do repozytorium całą jego zawartość, zachowując foldery `.github/workflows`, `agent` i `docs`.
3. W GitHub otwórz **Settings → Actions → General → Workflow permissions** i zezwól na **Read and write permissions** dla `GITHUB_TOKEN` (jeżeli repozytorium/organizacja pozwala).
4. W **Settings → Pages** wybierz jako źródło **GitHub Actions** i zapisz.
5. Otwórz zakładkę **Actions**, wybierz **CO Tanker Intelligence — Scheduled Public-Source Watch**, kliknij **Run workflow** i sprawdź wynik. Po wykonaniu zobacz `docs/data/intelligence.json` i raport z każdej witryny.
6. Po udanym kroku `deploy-pages` otrzymasz adres podobny do `https://YOURNAME.github.io/co-tanker-intelligence/`. Otwórz ten adres na Samsungu i wybierz **Dodaj do ekranu głównego / Install app**. Zakładka **Always-On Watch** będzie czytać `./data/intelligence.json` z Twojej witryny.
7. W desktopowym rozszerzeniu Chrome w zakładce **Always-On Watch** wpisz pełen adres **JSON**: `https://YOURNAME.github.io/co-tanker-intelligence/data/intelligence.json`. Kliknij **Save & connect** i zaakceptuj uprawnienie do odczytu tylko tego serwera.

Harmonogram jest ustawiony na próbę uruchomienia co 3 godziny czasu UTC. GitHub może opóźniać, pomijać lub wyłączać zaplanowane zadania przy bezczynności repozytorium; nie jest to SLA/24-godzinna gwarancja dostępności. Należy sprawdzać historię Actions i pole **Last successful fetch**. Jeśli wszystkie źródła zawiodą, wynik ma oznaczenie `ALL_SOURCES_FAILED` zamiast fałszywej wiadomości, że nie ma nowości.

## Co działa bez wdrożenia

- W Chrome: istniejący lokalny monitoring publikacji (tylko gdy Chrome pracuje), checklisty, trening, notatki i CO Planner.
- W Samsung PWA: checklisty, Academy, CO Planner, cache offline. Zakładka Always-On Watch pokazuje **NOT CONNECTED** lub **NOT DEPLOYED**, dopóki nie ma prawdziwego feedu.
- Dla Android plik HTML v1.4 pozostaje alternatywą całkowicie offline; nowa sekcja Always-On Watch wymaga PWA i zewnętrznego feedu.

## Co dokładnie robi aktualnie backend

Pobiera indeksy publikacji z publicznych stron bez obchodzenia loginów; wykrywa tytuły i linki; deduplikuje po źródle i adresie; zapisuje ostatnie sukcesy i błędy; publikuje ostrożne **guided-study prompts** oparte na konkretnych odnośnikach. Nie odczytuje pełnych tekstów prawnych i **nie potwierdza dat wejścia w życie**, nie wykonuje analizy zmian w PDF, nie integruje jeszcze modelu AI i nie zatwierdza checklist. To jest pierwszy działający szkielet architektury Always-On, nie kompletna realizacja całego Master Prompt v2.

## Rozwiązywanie problemów

- Brak danych: sprawdź kartę Actions i `docs/data/intelligence.json` — czy nie ma statusu `ALL_SOURCES_FAILED` i błędów 403/429 lub layoutu.
- Chrome `Cannot load extension` / `manifest missing`: rozpakuj **Chrome v1.5 ZIP** do osobnego folderu i wybierz w `chrome://extensions` właśnie ten folder z plikiem `manifest.json`.
- Android: GitHub Pages musi być HTTPS, a `index.html` musi pozostać w folderze `docs`.
- Po zmianie wersji: wykonaj **Export backup** ze starego rozszerzenia przed podmianą plików. Nie odinstalowuj bez backupu. Import jest możliwy w nowej wersji.
- Widoczny cache z dawnych godzin: sprawdź źródła, serwer i odśwież. Data publikacji serwerowego JSON nie jest datą publikacji wiadomości.

## Bezpieczeństwo danych

Aplikacja przechowuje lokalne notatki i statusy. Publiczny JSON zawiera tylko znalezione publiczne linki i ćwiczenia, nigdy notatki użytkownika. Projekt nie zawiera tajnych kluczy API. Potencjalne źródła członkowskie/interfejsy z uwierzytelnieniem są poza zakresem automatycznego monitorowania.
